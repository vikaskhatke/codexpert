<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- custom css -->
    <link rel="stylesheet" href="custom.css">
    <script src="script.js"></script>
    <title>codexpert</title>

    <style>
.carousel {
     width:100% !important; 
     overflow: hidden !important; 
     right:0 !important; 
}
    </style>

</head>

<body>
<?php include "partials/dbconnect.php" ?>
<?php include "partials/header.php" ?>
    

    <!-------------------------- carousel ------------------>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/crud2.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/crud5.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/crud1.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/crud4.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <h2 class="text-center" style="text-monospace">Welcome to the Codexpert</h2>

    <div class="container my-3 h-100">
        <div class="row h-100">
            <?php
                  $sql = "SELECT * FROM `categories`";
                  $result = mysqli_query($conn,$sql);
                   // $row=mysqli_fetch_assoc($result);
                  // echo var_dump($row);

                  while($row=mysqli_fetch_assoc($result)){
                      //echo $row['categories_id'];
                      //echo $row['categories_name'];
                      $categories_id = $row['categories_id']; 
                      $categories_name = $row['categories_name']; 
                      $categories_description = $row['categories_description']; 

                    echo
                      //<!----------------- card -------------->
                      '
                          <div class="col-md-4">
                              <div class="card my-2" style="width: 18rem;">
                                  <img src="https://source.unsplash.com/500x500/?'. $categories_name .',coding" class="card-img-top" alt="...">
                                  <div class="card-body">
                                      <h5 class="card-title"> <a href="threadlist.php?catid='.$categories_id.'">'. $categories_name .'</a></h5> 
                                      <p class="card-text">'.substr($categories_description, 0,100).'...</p>
                                    <a href="threadlist.php?catid='.$categories_id.'" class="btn btn-primary">Go for '. $categories_name .'</a>
                                  </div>
                              </div>     
                          </div>';
                  }
                ?>

            </div>
    </div>
    <?php include "partials/footer.php"; ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>

</html>