<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- custom css -->
    <link rel="stylesheet" href="custom.css">

    <title>top10</title>
</head>
<body>
<?php include "partials/header.php"; ?>
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">About Forum</h1>
    <p class="lead">Forum is an online discussion forum where youth or even the experienced professionals 
discuss their queries related to and get answers for their questions from other talented individuals. 
An online discussion can be started by asking questions, 
helping others with answers. The best part is that it is very simple and is free of cost.
You might think that forums, in general, are out of fashion nowadays, 
but we’re sorry to inform you that it’s not true at all. 

Have you ever found yourself in a situation which was driving you crazy? 
When you couldn’t find the right solution?
 Couldn’t find that bug or put in that final line of code to make everything work? 
Well, it happens to everyone and it’s cool when you can do it yourself.

Even if you are a skilled software developer, education is an ongoing process in our fast-paced, ever-changing times. 
The software developer forums you will find below help thousands of qualified professionals grow into 
masters of their craft.

Starting your career as a software engineer requires a lot of time, energy, and practice. 
If you want to accelerate this process, it is essential to use extra help and learn from professionals by 
looking into their cases, solutions, tips, etc. 
All the additional info and off-the-beaten track solutions can be found on the following programming forums..</p>
  </div>
</div>

</body>
<?php include "partials/footer.php"; ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>

</html>