<?php
session_start();
    // echo"Logging out please wait...";
    session_destroy();
    header ("location: /forum1/index.php");
    
    
?>