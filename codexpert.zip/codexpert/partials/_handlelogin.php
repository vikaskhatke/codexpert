<?php
$showError = "false";
if($_SERVER["REQUEST_METHOD"]=="POST"){              //Returns the request method used to access the page
    include 'dbconnect.php';
    $email = $_POST['loginEmail'];
    $password = $_POST['loginPass'];
    echo"<pre>";
      print_r ($_POST);
      $sql = "SELECT * FROM users where user_email='$email'";
    $result = mysqli_query($conn, $sql);

    $numRows = mysqli_num_rows($result);
    echo $numRows;
    if($numRows==1)
    {
        $resultrow = mysqli_fetch_assoc($result);
        echo"<pre>";
        print_r($resultrow);
            if(password_verify($password, $resultrow['user_pass'])){
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['sno'] = $resultrow['sno'];
                $_SESSION['userEmail'] = $email;
               header("location: /forum1/index.php?loginsuccess=true");
                echo "logged in".$email;

                exit();
            }
            else{
                $showError = "Invalid Password"; 
            }
    }
    else{
        $showError = "Invalid email address"; 
    }
    header ("location: /forum1/index.php?loggedin=false&error=".$showError);
}
?>