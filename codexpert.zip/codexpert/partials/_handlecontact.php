<?php 

if(isset($_POST['submit']))
{
$name = $_POST['name'];
$subject = $_POST['subject'];
$email = $_POST['email'];
$message = $_POST['message'];

$to = "vikaskhatke1994@gmail.com";

if(mail($to,$subject,$message,$email)){
    header("location: contact.php?success");
}
}
?>