<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "codexpert";

    $conn = mysqli_connect($servername, $username, $password, $database);
?>