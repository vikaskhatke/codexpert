<?php
echo
'<div class="container-fluid bg-dark text-center ">
    <div class="row" style="color:#fff ">
    <div class="links mt-2 col-md-12">
    <a  href="" class=" text-light text-decoration-none mx-3" style="text-decoration: none;" >About</a>
    <a  href="" class=" text-light mx-3" style="text-decoration: none;">Privacy</a>
    <a  href="" class=" text-light mx-3" style="text-decoration: none;">Support</a>
    <a  href="" class=" text-light mx-3" style="text-decoration: none;">Suggest a Feature</a>
    </div>
    <div class="mt-3 col-md-12">
    <p class="text-center" style="color:#A9A9A9;">Copyright: 2021 codexpert all right reserved. </p>
    </div>
    </div>
</div>';

?>