<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- custom css -->
    <link rel="stylesheet" href="custom.css">

    <title>codexpert</title>

    <style>

    </style>
</head>

<body>
    <?php include "partials/dbconnect.php" ?>
    <?php include "partials/header.php" ?>

    <?php 
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `categories` WHERE categories_id=$id";
        $result = mysqli_query($conn, $sql);
  
        while($row =mysqli_fetch_assoc($result)){
            
            $catname = $row['categories_name'];
            $catdesc = $row['categories_description'];
        }
    ?>
    <?php
        $showAlert = false;
        $method = $_SERVER['REQUEST_METHOD'];

        if($method=="POST"){
            $th_title = $_POST['title'];
            $th_desc = $_POST['desc'];
            $th_desc = str_replace("<","&lt", $th_desc);
            $th_desc = str_replace(">","&gt", $th_desc);
            $sno = $_POST['sno'];
            $sql = "INSERT INTO `threads` ( `thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `timestamp`) VALUES ( '$th_title', '$th_desc', '$id', '$sno', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            $showAlert = true;
            echo'
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success !</strong> Your thread has been added please wait to community respond.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }
    ?>

    <div class="container my-4">

        <div class="jumbotron ">
            <h1 class="display-4">Welcome to <?php echo $catname;?> forums</h1>
            <p class="lead"> <?php echo $catdesc; ?></p>
            <hr class="my-4">
            <p>This is peer to peer forum for sharing the knowledge with each other.
                No Spam / Advertising / Self-promote in the forums. ...
                Do not post copyright-infringing material. ...
                Do not post “offensive” posts, links or images. ...
                Do not cross post questions. ...
                Do not PM users asking for help. ...
                Remain respectful of other members at all times.
            </p>
            <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
        </div>

    </div>



    <!--------------- input form -------------->
    <?php

if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']=="true"){
echo'<div class="container">
    <h1 class="text-center">Ask a Quetion</h1>
        <form action="'. $_SERVER["REQUEST_URI"] .'" method="post" class="col-md-6 m-auto">
            <div class="form-group">
                <label for="exampleInput">Thread title</label>
                <input type="text" class="form-control" id="title" name="title"  Required>
                <small id="Help" class="form-text text-muted">Keep the title as short as posible</small>
            </div>
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Describe the concerns</label>
                <textarea class="form-control" id="desc" name="desc" rows="3"  Required></textarea>
            </div>
            <input type="hidden" name="sno" value="'.$_SESSION["sno"].'">
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>';
}

else{
    
    echo'
    <div class="container">
    <div class="alert alert-primary" role="alert">
    To ask a quetion please login!
    </div>
  </div>';
}
    ?>


    <div class="container my-3">
        <h1>Browse Quetions</h1>

        <?php 
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `threads` WHERE thread_cat_id=$id";
        $result = mysqli_query($conn, $sql);
        $noResult = true;
        while($row =mysqli_fetch_assoc($result)){
            $noResult = false;
            $id = $row ['thread_id'];
            $title = $row['thread_title'];
            $desc = $row['thread_desc'];
            // time
            $thread_time = $row['timestamp'];
            $date = str_replace('-"', '/', $thread_time); 
            $newDate = date("Y/m/d h:i A", strtotime($date)); 

            $thread_user_id = $row['thread_user_id'];
            $sql2 = "select user_email from `users` where sno=$thread_user_id";
            $result2 = mysqli_query($conn, $sql2);
            $row2 = mysqli_fetch_assoc($result2);
            
       echo '<div class="media my-4">
            
            <img src="img/default-person.jpg" width="60px" class="mr-3" alt="...">
            <div class="row">
            <div class="media-body">
           
                <h5 class="my-0"><a href="thread.php?threadid='.$id.'"> '.$title.' </a></h5>
                '.$desc.'    
            </div>
            </div>
            </div>

            <div>
            <p class="font-weight-bold mx-5 text-right">Asked By: '.$row2['user_email'].' at - '. $newDate .'</p>
           
            </div>    
            <hr style="width: 100%; color: black; height: 1px; background-color:black;"/>
            ';
    }

    if($noResult){
        echo'<div class="jumbotron jumbotron-fluid">
        <div class="container">
          <p class="display-4">No result found</p>
          <p class="lead">Be the first person to ask the quetion.</p>
        </div>
      </div>';
    }
    ?>



    </div>

    <?php include "partials/footer.php"; ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>

</html>